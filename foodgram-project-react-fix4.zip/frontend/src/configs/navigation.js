export default [
  {
    title: 'Рецепты',
    href: '/recipes',
    auth: false
  },{
    title: 'Мои подписки',
    href: '/subscriptions',
    auth: true
  },{
    title: 'Создать рецепт',
    href: '/recipes/create',
    auth: true
  },{
    title: 'Избранное',
    href: '/favorites',
    auth: true
  }, {
    title: 'Список покупок',
    href: '/cart',
    auth: true
  }
]